@echo off
setlocal
cd /d "%~dp0"
py -3 ".\build_remaining_release_v510.py" --base-config "%USERPROFILE%\Downloads\NEC 2026_지선\config_31_core_v41.json" --output-dir "%USERPROFILE%\Downloads\NEC_REMAINING_RELEASE_v510" --num-parts 24
pause
