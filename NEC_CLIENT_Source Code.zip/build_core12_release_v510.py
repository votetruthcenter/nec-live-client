# -*- coding: utf-8 -*-
from __future__ import annotations
import argparse, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent


def run(cmd):
    print("+", " ".join(str(x) for x in cmd))
    subprocess.check_call([str(x) for x in cmd], cwd=str(HERE))


def build_exe(skip_pip: bool = False) -> Path:
    if not skip_pip:
        run([sys.executable, "-m", "pip", "install", "-U", "selenium", "pyinstaller"])
    run([sys.executable, "-m", "PyInstaller", "--noconfirm", "--onefile", "--windowed", "--name", "NEC_Live_Client", "--hidden-import", "tkinter", "--hidden-import", "selenium", "--collect-all", "selenium", str(HERE / "nec_live_client_selenium_v510.py")])
    exe = HERE / "dist" / "NEC_Live_Client.exe"
    if not exe.exists():
        raise SystemExit(f"EXE not found after build: {exe}")
    return exe


def main():
    ap = argparse.ArgumentParser(description="Build v5.10 EXE and CORE01~CORE12 ZIPs")
    ap.add_argument("--base-config", required=True, type=Path)
    ap.add_argument("--output-dir", required=True, type=Path)
    ap.add_argument("--skip-pip", action="store_true")
    args = ap.parse_args()
    if not args.base_config.exists():
        raise SystemExit(f"base config not found: {args.base_config}")
    exe = build_exe(skip_pip=args.skip_pip)
    run([sys.executable, str(HERE / "make_core12_packages_v510.py"), "--base-config", str(args.base_config), "--output-dir", str(args.output_dir), "--exe", str(exe), "--strict"])
    print("DONE CORE12:", args.output_dir)

if __name__ == "__main__":
    main()
