NEC CLIENT BUILDER v510 - 전체 파일 포함판

이 ZIP에는 CORE12 / EXTRA24 배포 ZIP 생성에 필요한 파일을 모두 넣었습니다.
서버용 vote_page_place_public_html_full_v60 폴더에서 실행하지 마세요.
이 폴더 안에서 실행하세요.

필수 포함 파일:
- nec_live_client_selenium_v510.py
- build_core12_release_v510.py
- build_remaining_release_v510.py
- make_core12_packages_v510.py
- make_remaining_packages_v510.py

PowerShell:
cd "C:\Users\mycof\Downloads\Compressed\NEC_CLIENT_BUILDER_v510_FULL_ALL_FILES"

py -3 ".\build_core12_release_v510.py" --base-config "C:\Users\mycof\Downloads\NEC 2026_지선\config_31_core_v41.json" --output-dir "C:\Users\mycof\Downloads\NEC_CORE12_RELEASE_v510"

py -3 ".\build_remaining_release_v510.py" --base-config "C:\Users\mycof\Downloads\NEC 2026_지선\config_31_core_v41.json" --output-dir "C:\Users\mycof\Downloads\NEC_REMAINING_RELEASE_v510" --num-parts 24

또는:
RUN_1_BUILD_CORE12.bat
RUN_2_BUILD_EXTRA24.bat

[v5.10]
- 창 높이를 늘려 수집 진행 상황의 디스크 여유 공간 문구가 잘리지 않도록 수정했습니다.
