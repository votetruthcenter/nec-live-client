# -*- coding: utf-8 -*-
"""
make_remaining_packages_v510.py

Create distribution ZIPs for areas NOT covered by the CORE12 packages.

Important current rule:
- The latest CORE12 plan covers 31 areas, not 28:
  14 National Assembly by-elections + 17 governors.
- Therefore the non-CORE remainder is 170 - 31 = 139 areas = 417 targets.

This utility can create:
- NEC_Live_Client_EXTRA_ALL.zip: one package containing every remaining area.
- NEC_Live_Client_EXTRA01.zip ... EXTRA##.zip: split packages for additional volunteers.

Each ZIP contains:
- NEC_Live_Client.exe if --exe is supplied
- core_config.json filtered to the assigned remaining area subset
- client_settings.json pointing to core_config.json
- README_*.txt

msedgedriver.exe is intentionally NOT included. Selenium Manager resolves EdgeDriver on each PC.
"""

from __future__ import annotations

import argparse
import copy
import json
import re
import shutil
import uuid
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

SCHEDULE = [
    {"from": "18:30", "to": "19:00", "cycle_sleep_sec": 120},
    {"from": "19:00", "to": "20:00", "cycle_sleep_sec": 60},
    {"from": "20:00", "to": "21:00", "cycle_sleep_sec": 30},
    {"from": "21:00", "to": "24:00", "cycle_sleep_sec": 20},
    {"from": "00:00", "to": "05:00", "cycle_sleep_sec": 15},
]

# Current CORE12 area names. These are excluded from remaining packages.
CORE31_AREAS = [
    # 국회의원 재·보궐 14곳
    "부산 북구 갑", "대구 달성군", "인천 연수구 갑", "인천 계양구 을",
    "광주 광산구 을", "울산 남구 갑", "경기 평택시 을", "경기 안산시 갑",
    "경기 하남시 갑", "충남 공주시·부여군·청양군", "충남 아산시 을",
    "전북 군산시·김제시·부안군 갑", "전북 군산시·김제시·부안군 을", "제주 서귀포시",
    # 광역단체장 17곳
    "서울특별시장", "부산광역시장", "대구광역시장", "인천광역시장", "광주광역시장",
    "대전광역시장", "울산광역시장", "세종특별자치시장", "경기도지사", "강원특별자치도지사",
    "충청북도지사", "충청남도지사", "전북특별자치도지사", "전라남도지사",
    "경상북도지사", "경상남도지사", "제주특별자치도지사",
]

# This only exists for emergency compatibility with the older verbal "28 area" plan.
# It excludes the first 11 National Assembly areas + 17 governors, leaving 142 areas.
LEGACY28_AREAS = [
    "부산 북구 갑", "대구 달성군", "인천 연수구 갑", "인천 계양구 을",
    "광주 광산구 을", "울산 남구 갑", "경기 평택시 을", "경기 안산시 갑",
    "경기 하남시 갑", "충남 공주시·부여군·청양군", "충남 아산시 을",
    "서울특별시장", "부산광역시장", "대구광역시장", "인천광역시장", "광주광역시장",
    "대전광역시장", "울산광역시장", "세종특별자치시장", "경기도지사", "강원특별자치도지사",
    "충청북도지사", "충청남도지사", "전북특별자치도지사", "전라남도지사",
    "경상북도지사", "경상남도지사", "제주특별자치도지사",
]

CITY_PREFIX_TO_SIDO = {
    "서울": "서울특별시", "부산": "부산광역시", "대구": "대구광역시", "인천": "인천광역시",
    "광주": "광주광역시", "대전": "대전광역시", "울산": "울산광역시", "세종": "세종특별자치시",
    "경기": "경기도", "강원": "강원특별자치도", "충북": "충청북도", "충남": "충청남도",
    "전북": "전북특별자치도", "전남": "전라남도", "경북": "경상북도", "경남": "경상남도", "제주": "제주특별자치도",
}

@dataclass(frozen=True)
class AreaKey:
    priority_group: str
    election_type_raw: str
    sido_name: str
    unit_name: str


def norm(value: Any) -> str:
    return re.sub(r"[\s·ㆍ\-()]+", "", str(value or "").strip())


def row_of(target: Dict[str, Any]) -> Dict[str, Any]:
    row = target.get("_original_row")
    return row if isinstance(row, dict) else {}


def area_key_from_target(target: Dict[str, Any]) -> AreaKey:
    row = row_of(target)
    return AreaKey(
        str(row.get("priority_group") or ""),
        str(row.get("election_type_raw") or row.get("election_type") or target.get("election_type") or ""),
        str(row.get("sido_name") or row.get("city_name") or ""),
        str(row.get("unit_name") or ""),
    )


def compact_city_label(text: str) -> str:
    val = str(text or "").strip()
    val = val.replace("서울특별시장", "서울시장")
    val = val.replace("세종특별자치시장", "세종시장")
    for city in ("부산", "대구", "인천", "광주", "대전", "울산"):
        val = val.replace(f"{city}광역시장", f"{city}시장")
    return val


def display_name_from_key(key: AreaKey, sample_target: Dict[str, Any]) -> str:
    row = row_of(sample_target)
    office = str(row.get("office_name") or "").strip()
    pg = key.priority_group
    et = key.election_type_raw
    sido = key.sido_name
    unit = key.unit_name
    if "국회의원" in et:
        # Display with short province prefix if available.
        short = next((k for k, v in CITY_PREFIX_TO_SIDO.items() if v == sido), sido)
        # Unit in manifest may already omit spaces, which is fine for display.
        return f"{short} {unit}".strip()
    if "시도지사" in et:
        return compact_city_label(office or unit or sido)
    if "교육감" in et:
        return office or f"{sido}교육감"
    if "구시군의장" in et or "구·시·군" in str(sample_target.get("election_type") or ""):
        if office:
            return office
        return f"{sido} {unit}".strip()
    return office or f"{sido} {unit}".strip()


def area_name_to_key(area_name: str) -> Tuple[str, str, str]:
    """Return loose identifiers (election type marker, sido, unit/office) for CORE exclusions."""
    a = str(area_name).strip()
    # Governors
    if a.endswith("시장") or a.endswith("도지사"):
        sido = ""
        if a == "서울특별시장": sido = "서울특별시"
        elif a == "부산광역시장": sido = "부산광역시"
        elif a == "대구광역시장": sido = "대구광역시"
        elif a == "인천광역시장": sido = "인천광역시"
        elif a == "광주광역시장": sido = "광주광역시"
        elif a == "대전광역시장": sido = "대전광역시"
        elif a == "울산광역시장": sido = "울산광역시"
        elif a == "세종특별자치시장": sido = "세종특별자치시"
        elif a == "경기도지사": sido = "경기도"
        elif a == "강원특별자치도지사": sido = "강원특별자치도"
        elif a == "충청북도지사": sido = "충청북도"
        elif a == "충청남도지사": sido = "충청남도"
        elif a == "전북특별자치도지사": sido = "전북특별자치도"
        elif a == "전라남도지사": sido = "전라남도"
        elif a == "경상북도지사": sido = "경상북도"
        elif a == "경상남도지사": sido = "경상남도"
        elif a == "제주특별자치도지사": sido = "제주특별자치도"
        return ("시도지사선거", sido, sido)
    # National Assembly by-election area names start with a province short label.
    for short, sido in CITY_PREFIX_TO_SIDO.items():
        if a.startswith(short + " "):
            return ("국회의원선거", sido, a[len(short)+1:].strip())
    return ("", "", a)


def make_exclusion_keys(mode: str) -> set[AreaKey]:
    areas = LEGACY28_AREAS if mode == "legacy28" else CORE31_AREAS
    out: set[AreaKey] = set()
    for area in areas:
        et, sido, unit = area_name_to_key(area)
        out.add(AreaKey("", et, sido, unit))
    return out


def is_excluded(key: AreaKey, exclusions: set[AreaKey]) -> bool:
    for ex in exclusions:
        if ex.election_type_raw and norm(ex.election_type_raw) not in norm(key.election_type_raw):
            continue
        if ex.sido_name and norm(ex.sido_name) != norm(key.sido_name):
            continue
        if ex.unit_name and norm(ex.unit_name) != norm(key.unit_name):
            continue
        return True
    return False


def ensure_step(path: List[Dict[str, Any]], text: str, contains: bool = True) -> bool:
    if not text:
        return False
    if any(norm(step.get("text")) == norm(text) for step in path if isinstance(step, dict)):
        return False
    path.append({"text": text, "contains": contains})
    return True


def patch_select_path(target: Dict[str, Any]) -> bool:
    """Patch select_path for National Assembly and local mayor/county mayor targets."""
    row = row_of(target)
    et_raw = str(row.get("election_type_raw") or target.get("election_type") or "")
    unit = str(row.get("unit_name") or "").strip()
    sido = str(row.get("sido_name") or row.get("city_name") or "").strip()
    path = target.get("select_path")
    if not isinstance(path, list):
        path = []
    changed = False
    if "국회의원" in et_raw:
        # Province/city + district is required.
        changed = ensure_step(path, unit, True) or changed
        if changed:
            target["_select_path_patched"] = "congress_city_plus_district"
    elif "구시군의장" in et_raw or "구·시·군" in str(target.get("election_type") or ""):
        # Local executive targets must select the city/county/district after province/city.
        if unit and norm(unit) != norm(sido):
            changed = ensure_step(path, unit, True) or changed
            if changed:
                target["_select_path_patched"] = "local_executive_city_plus_unit"
    target["select_path"] = path
    return changed


def load_base_config(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def group_targets_by_area(config: Dict[str, Any]) -> Dict[AreaKey, List[Dict[str, Any]]]:
    grouped: Dict[AreaKey, List[Dict[str, Any]]] = {}
    for target in config.get("targets", []):
        if not isinstance(target, dict):
            continue
        key = area_key_from_target(target)
        grouped.setdefault(key, []).append(target)
    return grouped


def split_balanced(items: List[Tuple[AreaKey, str, List[Dict[str, Any]]]], parts: int) -> List[List[Tuple[AreaKey, str, List[Dict[str, Any]]]]]:
    if parts <= 0:
        return []
    buckets: List[List[Tuple[AreaKey, str, List[Dict[str, Any]]]]] = [[] for _ in range(parts)]
    weights = [0] * parts
    # Sort larger target groups first. They should all be 3, but this keeps it robust.
    for item in sorted(items, key=lambda x: len(x[2]), reverse=True):
        idx = min(range(parts), key=lambda i: (weights[i], i))
        buckets[idx].append(item)
        weights[idx] += len(item[2])
    return buckets


def make_client_settings(client_id: str) -> Dict[str, Any]:
    return {
        "client_id": client_id,
        "client_secret": uuid.uuid4().hex + uuid.uuid4().hex,
        "config_url": "core_config.json",
        "headless": True,
        "loop_enabled": True,
    }


def make_config(base: Dict[str, Any], client_id: str, display_names: List[str], targets: List[Dict[str, Any]], version_suffix: str) -> Dict[str, Any]:
    cfg = copy.deepcopy(base)
    cfg["version"] = f"remaining_{client_id}_{version_suffix}"
    cfg["description"] = f"{client_id} remaining assigned areas: " + ", ".join(display_names)
    cfg["client_id"] = client_id
    cfg["edge_driver_path"] = ""  # Selenium Manager fallback
    cfg["cycle_schedule"] = SCHEDULE
    cfg["per_target_delay_min_sec"] = float(cfg.get("per_target_delay_min_sec") or 1.0)
    cfg["per_target_delay_max_sec"] = float(cfg.get("per_target_delay_max_sec") or 3.0)
    cfg["display_area"] = ", ".join(display_names) if len(display_names) <= 18 else f"CORE12 제외 나머지 {len(display_names)}개 대상"
    cfg["targets"] = targets
    cfg["_assigned_area_names"] = display_names
    cfg["_assigned_area_count"] = len(display_names)
    cfg["_assigned_target_count"] = len(targets)
    return cfg


def write_zip(out_zip: Path, work_dir: Path) -> None:
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(work_dir.rglob("*")):
            if p.is_file():
                zf.write(p, arcname=str(p.relative_to(work_dir)))


def create_package(output_dir: Path, client_id: str, base_config: Dict[str, Any], item_list: List[Tuple[AreaKey, str, List[Dict[str, Any]]]], exe: Path | None, version_suffix: str) -> Dict[str, Any]:
    client_dir = output_dir / client_id
    if client_dir.exists():
        shutil.rmtree(client_dir)
    client_dir.mkdir(parents=True, exist_ok=True)

    targets: List[Dict[str, Any]] = []
    display_names: List[str] = []
    patched = 0
    counts_by_area: Dict[str, int] = {}
    for _key, name, tgts in item_list:
        display_names.append(name)
        counts_by_area[name] = len(tgts)
        for target in tgts:
            cloned = copy.deepcopy(target)
            cloned["assigned_client_ids"] = [client_id]
            cloned["_remaining_area_display"] = name
            if patch_select_path(cloned):
                patched += 1
            targets.append(cloned)

    cfg = make_config(base_config, client_id, display_names, targets, version_suffix)
    (client_dir / "core_config.json").write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    (client_dir / "client_settings.json").write_text(json.dumps(make_client_settings(client_id), ensure_ascii=False, indent=2), encoding="utf-8")

    readme = f"""6.3 지방 선거 개표 상황 정보 수집 프로그램 - {client_id}

이 배포본은 CORE12가 맡지 않는 나머지 영역 수집용입니다.
담당 대상 수: {len(display_names)}개
수집 화면 수: {len(targets)}개

실행 방법:
1. ZIP 압축을 풉니다.
2. NEC_Live_Client.exe를 실행합니다.
3. '수집 및 공유 동의' 버튼을 누릅니다.
4. 6월 3일 19시부터 6월 4일 새벽 5시까지 컴퓨터를 켜두십시오.

담당 대상:
{chr(10).join('- ' + n for n in display_names)}
"""
    (client_dir / f"README_{client_id}.txt").write_text(readme, encoding="utf-8")

    included = []
    if exe and exe.exists():
        shutil.copy2(exe, client_dir / "NEC_Live_Client.exe")
        included.append("NEC_Live_Client.exe")

    out_zip = output_dir / f"NEC_Live_Client_{client_id}.zip"
    if out_zip.exists():
        out_zip.unlink()
    write_zip(out_zip, client_dir)

    return {
        "client_id": client_id,
        "area_count": len(display_names),
        "target_count": len(targets),
        "patched_select_paths": patched,
        "counts_by_area": counts_by_area,
        "zip": str(out_zip),
        "included_common_files": included,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="Create remaining-area NEC Live Client packages.")
    ap.add_argument("--base-config", type=Path, required=True, help="Full config JSON, preferably config_31_core_v510.json")
    ap.add_argument("--output-dir", type=Path, required=True, help="Output folder")
    ap.add_argument("--exe", type=Path, default=None, help="Built NEC_Live_Client.exe. Optional; omit for config-only package tests.")
    ap.add_argument("--num-parts", type=int, default=24, help="Number of split EXTRA packages. Default: 24. Use 0 to skip split packages.")
    ap.add_argument("--exclude-mode", choices=["current31", "legacy28"], default="current31", help="current31 excludes the actual CORE12 31 areas; legacy28 excludes only the older 28 areas.")
    ap.add_argument("--no-all", action="store_true", help="Do not create EXTRA_ALL package.")
    ap.add_argument("--strict", action="store_true", help="Fail if base area grouping is not exactly 170 areas x 3 targets, or if remaining counts are unexpected.")
    args = ap.parse_args()

    base = load_base_config(args.base_config)
    grouped = group_targets_by_area(base)
    problems = {str(k): len(v) for k, v in grouped.items() if len(v) != 3}
    if args.strict and (len(grouped) != 170 or problems):
        raise SystemExit(f"ERROR: expected 170 areas with 3 targets each; got areas={len(grouped)} problems={problems}")

    exclusions = make_exclusion_keys(args.exclude_mode)
    remaining_items: List[Tuple[AreaKey, str, List[Dict[str, Any]]]] = []
    excluded_items: List[Tuple[AreaKey, str, List[Dict[str, Any]]]] = []
    for key, tgts in grouped.items():
        name = display_name_from_key(key, tgts[0])
        if is_excluded(key, exclusions):
            excluded_items.append((key, name, tgts))
        else:
            remaining_items.append((key, name, tgts))

    remaining_items.sort(key=lambda x: (x[0].priority_group, x[0].sido_name, x[0].unit_name, x[1]))
    args.output_dir.mkdir(parents=True, exist_ok=True)

    expected_remaining = 139 if args.exclude_mode == "current31" else 142
    if args.strict and len(remaining_items) != expected_remaining:
        raise SystemExit(f"ERROR: expected remaining={expected_remaining} for {args.exclude_mode}, got {len(remaining_items)}")

    audit: Dict[str, Any] = {
        "base_config": str(args.base_config),
        "exclude_mode": args.exclude_mode,
        "total_base_targets": len(base.get("targets", [])),
        "total_base_areas": len(grouped),
        "excluded_area_count": len(excluded_items),
        "remaining_area_count": len(remaining_items),
        "remaining_target_count": sum(len(x[2]) for x in remaining_items),
        "area_group_size_problems": problems,
        "packages": {},
    }

    if not args.no_all:
        audit["packages"]["EXTRA_ALL"] = create_package(args.output_dir, "EXTRA_ALL", base, remaining_items, args.exe, "v4_6")
        print(f"EXTRA_ALL: AREAS={len(remaining_items)} TARGETS={sum(len(x[2]) for x in remaining_items)} ZIP={audit['packages']['EXTRA_ALL']['zip']}")

    if args.num_parts > 0:
        buckets = split_balanced(remaining_items, args.num_parts)
        for i, bucket in enumerate(buckets, start=1):
            if not bucket:
                continue
            cid = f"EXTRA{i:02d}"
            audit["packages"][cid] = create_package(args.output_dir, cid, base, bucket, args.exe, "v4_6")
            print(f"{cid}: AREAS={len(bucket)} TARGETS={sum(len(x[2]) for x in bucket)} ZIP={audit['packages'][cid]['zip']}")

    audit_path = args.output_dir / "remaining_package_audit.json"
    audit_path.write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"AUDIT={audit_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
