# -*- coding: utf-8 -*-
"""
make_core12_packages_v510.py

Create 12 volunteer ZIP packages from one full config JSON.
Each ZIP contains:
- the common NEC_Live_Client.exe if --exe is supplied
- msedgedriver.exe if --driver is supplied
- core_config.json filtered to that CORE person's assigned 31-area subset
- client_settings.json pointing to core_config.json
- README_COREXX.txt

No Selenium is used here. This is an operator-side packaging utility.
"""

from __future__ import annotations

import argparse
import copy
import json
import re
import shutil
import uuid
import zipfile
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

SCHEDULE = [
    {"from": "18:30", "to": "19:00", "cycle_sleep_sec": 120},
    {"from": "19:00", "to": "20:00", "cycle_sleep_sec": 60},
    {"from": "20:00", "to": "21:00", "cycle_sleep_sec": 30},
    {"from": "21:00", "to": "24:00", "cycle_sleep_sec": 20},
    {"from": "00:00", "to": "05:00", "cycle_sleep_sec": 15},
]

# 31 target areas selected by the operator: 14 National Assembly by-elections + 17 governors.
AREA_SPECS: Dict[str, Dict[str, Any]] = {
    # 국회의원 재·보궐 14곳
    "부산 북구 갑": {"kind": "국회의원선거", "terms": [["부산", "부산광역시"], ["북구"], ["갑"]]},
    "대구 달성군": {"kind": "국회의원선거", "terms": [["대구", "대구광역시"], ["달성"]]},
    "인천 연수구 갑": {"kind": "국회의원선거", "terms": [["인천", "인천광역시"], ["연수"], ["갑"]]},
    "인천 계양구 을": {"kind": "국회의원선거", "terms": [["인천", "인천광역시"], ["계양"], ["을"]]},
    "광주 광산구 을": {"kind": "국회의원선거", "terms": [["광주", "광주광역시"], ["광산"], ["을"]]},
    "울산 남구 갑": {"kind": "국회의원선거", "terms": [["울산", "울산광역시"], ["남구"], ["갑"]]},
    "경기 평택시 을": {"kind": "국회의원선거", "terms": [["경기", "경기도"], ["평택"], ["을"]]},
    "경기 안산시 갑": {"kind": "국회의원선거", "terms": [["경기", "경기도"], ["안산"], ["갑"]]},
    "경기 하남시 갑": {"kind": "국회의원선거", "terms": [["경기", "경기도"], ["하남"], ["갑"]]},
    "충남 공주시·부여군·청양군": {"kind": "국회의원선거", "terms": [["충남", "충청남도"], ["공주"], ["부여"], ["청양"]]},
    "충남 아산시 을": {"kind": "국회의원선거", "terms": [["충남", "충청남도"], ["아산"], ["을"]]},
    "전북 군산시·김제시·부안군 갑": {"kind": "국회의원선거", "terms": [["전북", "전북특별자치도"], ["군산"], ["김제"], ["부안"], ["갑"]]},
    "전북 군산시·김제시·부안군 을": {"kind": "국회의원선거", "terms": [["전북", "전북특별자치도"], ["군산"], ["김제"], ["부안"], ["을"]]},
    "제주 서귀포시": {"kind": "국회의원선거", "terms": [["제주", "제주특별자치도"], ["서귀포"]]},
    # 광역단체장 17곳
    "서울특별시장": {"kind": "시도지사선거", "terms": [["서울", "서울특별시"]]},
    "부산광역시장": {"kind": "시도지사선거", "terms": [["부산", "부산광역시"]]},
    "대구광역시장": {"kind": "시도지사선거", "terms": [["대구", "대구광역시"]]},
    "인천광역시장": {"kind": "시도지사선거", "terms": [["인천", "인천광역시"]]},
    "광주광역시장": {"kind": "시도지사선거", "terms": [["광주", "광주광역시"]]},
    "대전광역시장": {"kind": "시도지사선거", "terms": [["대전", "대전광역시"]]},
    "울산광역시장": {"kind": "시도지사선거", "terms": [["울산", "울산광역시"]]},
    "세종특별자치시장": {"kind": "시도지사선거", "terms": [["세종", "세종특별자치시"]]},
    "경기도지사": {"kind": "시도지사선거", "terms": [["경기", "경기도"]]},
    "강원특별자치도지사": {"kind": "시도지사선거", "terms": [["강원", "강원특별자치도"]]},
    "충청북도지사": {"kind": "시도지사선거", "terms": [["충북", "충청북도"]]},
    "충청남도지사": {"kind": "시도지사선거", "terms": [["충남", "충청남도"]]},
    "전북특별자치도지사": {"kind": "시도지사선거", "terms": [["전북", "전북특별자치도"]]},
    "전라남도지사": {"kind": "시도지사선거", "terms": [["전남", "전라남도"]]},
    "경상북도지사": {"kind": "시도지사선거", "terms": [["경북", "경상북도"]]},
    "경상남도지사": {"kind": "시도지사선거", "terms": [["경남", "경상남도"]]},
    "제주특별자치도지사": {"kind": "시도지사선거", "terms": [["제주", "제주특별자치도"]]},
}

CORE_ASSIGNMENTS: Dict[str, List[str]] = {
    "CORE01": ["부산 북구 갑", "경기 하남시 갑", "부산광역시장", "강원특별자치도지사", "전라남도지사", "제주 서귀포시"],
    "CORE02": ["대구 달성군", "충남 공주시·부여군·청양군", "대구광역시장", "충청북도지사", "경상북도지사"],
    "CORE03": ["인천 연수구 갑", "충남 아산시 을", "인천광역시장", "충청남도지사", "경상남도지사"],
    "CORE04": ["인천 계양구 을", "서울특별시장", "광주광역시장", "전북특별자치도지사", "제주특별자치도지사"],
    "CORE05": ["부산 북구 갑", "광주 광산구 을", "부산광역시장", "대전광역시장", "전라남도지사"],
    "CORE06": ["대구 달성군", "울산 남구 갑", "대구광역시장", "울산광역시장", "경상북도지사"],
    "CORE07": ["인천 연수구 갑", "경기 평택시 을", "인천광역시장", "세종특별자치시장", "경상남도지사"],
    "CORE08": ["인천 계양구 을", "경기 안산시 갑", "광주광역시장", "경기도지사", "제주특별자치도지사"],
    "CORE09": ["광주 광산구 을", "경기 하남시 갑", "대전광역시장", "강원특별자치도지사", "전북 군산시·김제시·부안군 갑"],
    "CORE10": ["울산 남구 갑", "충남 공주시·부여군·청양군", "울산광역시장", "충청북도지사", "전북 군산시·김제시·부안군 을"],
    "CORE11": ["경기 평택시 을", "충남 아산시 을", "세종특별자치시장", "충청남도지사", "전북 군산시·김제시·부안군 갑"],
    "CORE12": ["경기 안산시 갑", "서울특별시장", "경기도지사", "전북특별자치도지사", "전북 군산시·김제시·부안군 을", "제주 서귀포시"],
}


def norm(value: Any) -> str:
    return re.sub(r"\s+", "", str(value or "")).replace("·", "").replace("ㆍ", "")


def collect_strings(obj: Any, out: List[str]) -> None:
    if isinstance(obj, dict):
        for v in obj.values():
            collect_strings(v, out)
    elif isinstance(obj, list):
        for v in obj:
            collect_strings(v, out)
    elif isinstance(obj, (str, int, float)):
        text = str(obj).strip()
        if text:
            out.append(text)


def target_text(target: Dict[str, Any]) -> str:
    values: List[str] = []
    # Keep matching robust by scanning all text fields in the target.
    collect_strings(target, values)
    return norm(" ".join(values))


def election_text(target: Dict[str, Any]) -> str:
    row = target.get("_original_row") if isinstance(target.get("_original_row"), dict) else {}
    vals = [target.get("election_type"), row.get("election_type_raw"), row.get("election_type"), row.get("선거종류")]
    return norm(" ".join(str(v or "") for v in vals))


def kind_matches(target: Dict[str, Any], kind: str) -> bool:
    e = election_text(target)
    alltxt = target_text(target)
    if kind == "시도지사선거":
        return ("시도지사" in e or "시도지사" in alltxt or "시·도지사" in str(target))
    if kind == "국회의원선거":
        return ("국회의원" in e or "국회의원" in alltxt)
    return norm(kind) in e or norm(kind) in alltxt


def terms_match(text: str, term_groups: List[List[str]]) -> bool:
    for group in term_groups:
        if not any(norm(term) in text for term in group):
            return False
    return True


def target_matches_area(target: Dict[str, Any], area_name: str) -> bool:
    spec = AREA_SPECS[area_name]
    if not kind_matches(target, str(spec["kind"])):
        return False
    return terms_match(target_text(target), spec["terms"])


def filter_targets_for_areas(all_targets: List[Dict[str, Any]], areas: List[str]) -> Tuple[List[Dict[str, Any]], Dict[str, int]]:
    selected: List[Dict[str, Any]] = []
    seen = set()
    counts: Dict[str, int] = {}
    for area in areas:
        matches = []
        for target in all_targets:
            if target_matches_area(target, area):
                tid = str(target.get("target_id") or target.get("id") or json.dumps(target, ensure_ascii=False)[:200])
                matches.append((tid, target))
        counts[area] = len(matches)
        for tid, target in matches:
            if tid in seen:
                continue
            cloned = copy.deepcopy(target)
            cloned["assigned_client_ids"] = []
            cloned["_core_area"] = area
            selected.append(cloned)
            seen.add(tid)
    return selected, counts

def area_unit_for_congress(area_name: str) -> str:
    """Return the election-district label to pick in NEC select boxes."""
    prefixes = [
        "부산 ", "대구 ", "인천 ", "광주 ", "울산 ", "경기 ", "충남 ", "전북 ", "제주 ",
        "부산광역시 ", "대구광역시 ", "인천광역시 ", "광주광역시 ", "울산광역시 ",
        "경기도 ", "충청남도 ", "전북특별자치도 ", "제주특별자치도 ",
    ]
    val = str(area_name or "").strip()
    for prefix in prefixes:
        if val.startswith(prefix):
            return val[len(prefix):].strip()
    return val


def normalize_select_label(text: str) -> str:
    return re.sub(r"\s+", "", str(text or "").strip())


def ensure_congress_select_path(target: Dict[str, Any]) -> bool:
    """Patch National Assembly targets to select province/city + district."""
    row = target.get("_original_row") if isinstance(target.get("_original_row"), dict) else {}
    etype = normalize_select_label(target.get("election_type") or row.get("election_type_raw") or "")
    if "국회의원" not in etype:
        return False
    path = target.get("select_path")
    if not isinstance(path, list):
        path = []
    if len(path) >= 2:
        target["select_path"] = path
        return False
    unit = str(row.get("unit_name") or "").strip()
    if target.get("_core_area"):
        unit = area_unit_for_congress(str(target.get("_core_area")))
    if not unit:
        target["select_path"] = path
        return False
    sido = str(row.get("sido_name") or row.get("city_name") or "").strip()
    if normalize_select_label(unit) == normalize_select_label(sido):
        target["select_path"] = path
        return False
    path.append({"text": unit, "contains": True})
    target["select_path"] = path
    target["_select_path_patched"] = "congress_city_plus_district"
    return True



def make_client_settings(core_id: str) -> Dict[str, Any]:
    return {
        "client_id": core_id,
        "client_secret": uuid.uuid4().hex + uuid.uuid4().hex,
        "config_url": "core_config.json",
        "headless": True,
        "loop_enabled": True,
    }



def compact_area_label(text: str) -> str:
    val = str(text or "").strip()
    val = val.replace("서울특별시장", "서울시장")
    val = val.replace("세종특별자치시장", "세종시장")
    for city in ("부산", "대구", "인천", "광주", "대전", "울산"):
        val = val.replace(f"{city}광역시장", f"{city}시장")
    return val

def make_core_config(base_config: Dict[str, Any], core_id: str, targets: List[Dict[str, Any]], areas: List[str]) -> Dict[str, Any]:
    cfg = copy.deepcopy(base_config)
    cfg["version"] = f"core12_{core_id}_v4_6"
    cfg["description"] = f"{core_id} assigned areas: " + ", ".join(areas)
    cfg["client_id"] = core_id
    # No bundled msedgedriver.exe in v4.1 CORE ZIPs. Let Selenium Manager resolve EdgeDriver.
    cfg["edge_driver_path"] = ""
    display_areas = [compact_area_label(a) for a in areas]
    cfg["display_area"] = ", ".join(display_areas)
    patched_count = 0
    for t in targets:
        if isinstance(t, dict) and t.get("_core_area"):
            t["_core_area_display"] = compact_area_label(str(t.get("_core_area")))
        if isinstance(t, dict) and ensure_congress_select_path(t):
            patched_count += 1
    cfg["cycle_schedule"] = cfg.get("cycle_schedule") or SCHEDULE
    cfg["per_target_delay_min_sec"] = float(cfg.get("per_target_delay_min_sec", 1.0))
    cfg["per_target_delay_max_sec"] = float(cfg.get("per_target_delay_max_sec", 3.0))
    cfg["targets"] = targets
    cfg["_core_assignment"] = {"core_id": core_id, "areas": areas, "target_count": len(targets), "congress_select_path_patched": patched_count}
    return cfg


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def make_readme(core_id: str, areas: List[str], target_count: int) -> str:
    return f"""6.3 지방선거 개표상황표 수집 프로그램 - {core_id}\n\n담당 지역:\n- """ + "\n- ".join(areas) + f"""\n\n수집 화면 수: {target_count}개\n\n실행 방법:\n1. 압축을 풉니다.\n2. NEC_Live_Client.exe를 실행합니다.\n3. '수집 및 공유 동의' 버튼을 누릅니다.\n4. 6월 3일 19시부터 6월 4일 새벽 5시까지 컴퓨터를 끄지 말아 주세요.\n\n주의:\n- core_config.json을 삭제하지 마세요.\n- 이 배포본은 msedgedriver.exe를 포함하지 않습니다. 프로그램이 EdgeDriver를 자동으로 준비합니다.\n"""


def add_if_exists(zf: zipfile.ZipFile, path: Path, arcname: str) -> None:
    if path and path.exists() and path.is_file():
        zf.write(path, arcname)


def main() -> int:
    parser = argparse.ArgumentParser(description="Make CORE01~CORE12 ZIP packages from a full config JSON")
    parser.add_argument("--base-config", required=True, type=Path, help="full config JSON containing all target definitions")
    parser.add_argument("--output-dir", required=True, type=Path, help="output directory for CORE ZIP packages")
    parser.add_argument("--exe", type=Path, default=None, help="optional NEC_Live_Client.exe path to include in each ZIP")
    parser.add_argument("--driver", type=Path, default=None, help="optional msedgedriver.exe path to include in each ZIP")
    parser.add_argument("--strict", action="store_true", help="return error if any assigned area does not match exactly 3 targets")
    args = parser.parse_args()

    base_config = json.loads(args.base_config.read_text(encoding="utf-8-sig"))
    all_targets = base_config.get("targets") or []
    if not isinstance(all_targets, list):
        print("ERROR: base-config targets must be a list")
        return 1

    args.output_dir.mkdir(parents=True, exist_ok=True)
    audit = {"base_config": str(args.base_config), "total_base_targets": len(all_targets), "cores": {}}
    error_count = 0

    for core_id, areas in CORE_ASSIGNMENTS.items():
        targets, counts = filter_targets_for_areas(all_targets, areas)
        core_config = make_core_config(base_config, core_id, targets, areas)
        work = args.output_dir / core_id
        if work.exists():
            shutil.rmtree(work)
        work.mkdir(parents=True)
        write_json(work / "core_config.json", core_config)
        write_json(work / "client_settings.json", make_client_settings(core_id))
        (work / "client_id.txt").write_text(core_id, encoding="utf-8")
        (work / f"README_{core_id}.txt").write_text(make_readme(core_id, areas, len(targets)), encoding="utf-8")
        add_files = []
        if args.exe and args.exe.exists() and args.exe.is_file():
            shutil.copy2(args.exe, work / "NEC_Live_Client.exe")
            add_files.append("NEC_Live_Client.exe")
        if args.driver and args.driver.exists() and args.driver.is_file() and args.driver.stat().st_size > 0:
            shutil.copy2(args.driver, work / "msedgedriver.exe")
            add_files.append("msedgedriver.exe")

        zip_path = args.output_dir / f"NEC_Live_Client_{core_id}.zip"
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for p in work.rglob("*"):
                if p.is_file():
                    zf.write(p, p.relative_to(work))

        bad_areas = {area: cnt for area, cnt in counts.items() if cnt != 3}
        if bad_areas:
            error_count += len(bad_areas)
        audit["cores"][core_id] = {
            "areas": areas,
            "target_count": len(targets),
            "counts_by_area": counts,
            "bad_areas_not_3_targets": bad_areas,
            "zip": str(zip_path),
            "included_common_files": add_files,
            "client_id_txt": core_id,
            "congress_select_path_patched": core_config.get("_core_assignment", {}).get("congress_select_path_patched", 0),
            "edge_driver_path": core_config.get("edge_driver_path", ""),
        }
        print(f"{core_id}: AREAS={len(areas)} TARGETS={len(targets)} ZIP={zip_path}")
        if bad_areas:
            print(f"  WARNING bad area counts: {bad_areas}")

    # Verify every one of the 31 areas is assigned exactly twice across CORE01~CORE12.
    area_assignment_count: Dict[str, int] = {area: 0 for area in AREA_SPECS}
    for areas in CORE_ASSIGNMENTS.values():
        for area in areas:
            area_assignment_count[area] += 1
    audit["area_assignment_count"] = area_assignment_count
    wrong_dupe = {area: cnt for area, cnt in area_assignment_count.items() if cnt != 2}
    audit["areas_not_assigned_twice"] = wrong_dupe
    if wrong_dupe:
        error_count += len(wrong_dupe)
        print(f"WARNING areas not assigned exactly twice: {wrong_dupe}")

    audit_path = args.output_dir / "core12_package_audit.json"
    write_json(audit_path, audit)
    print(f"AUDIT={audit_path}")
    if args.strict and error_count:
        print(f"ERROR: strict mode found {error_count} issues")
        return 2
    print("DONE")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
