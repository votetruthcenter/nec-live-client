NEC Live Client C# WinForms Sample v1

목적
- Tkinter 대신 C# WinForms로 만든 자원봉사자용 Windows Portable 클라이언트 샘플입니다.
- 큰 글씨, 큰 버튼, 단순한 화면 구성을 확인하기 위한 디자인/동작 샘플입니다.
- 설치형이 아니라 Portable ZIP 방식으로 배포하는 전제를 사용합니다.

자원봉사자 PC
- Python 설치 필요 없음
- .NET SDK 설치 필요 없음
- 관리자 권한 필요 없음
- 압축 풀고 NEC_Live_Client.exe 실행

운영자 PC에서 빌드
1. .NET 8 SDK 설치
2. build_portable_windows.bat 실행
3. publish\NEC_Live_Client 폴더 확인
4. make_release_zip_windows.ps1 실행
5. 생성된 ZIP을 GitHub Releases에 업로드

실제 운영 전 수정할 것
- publish\NEC_Live_Client\config\client_local.json
  - HostingKR 주소
  - client_id
  - upload_token
- HostingKR에 아래 JSON 업로드
  - config_current.json
  - control.json
  - message_current.json

샘플 JSON
- config_current.sample.json
- control.sample.json
- message_current.sample.json

주의
- 현재 target은 https://example.com/ 샘플입니다.
- 실제 NEC POST 구조는 나중에 config_current.json에서 교체합니다.
