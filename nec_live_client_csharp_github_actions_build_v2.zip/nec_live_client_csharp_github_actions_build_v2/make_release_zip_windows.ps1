$ErrorActionPreference = "Stop"
Set-Location -LiteralPath $PSScriptRoot

$releaseName = "NEC_Live_Client_CSharp_Portable_v20260603_sample1"
$folder = Join-Path $PSScriptRoot "publish\NEC_Live_Client"
if (!(Test-Path -LiteralPath $folder)) {
    throw "publish\NEC_Live_Client not found. Run build_portable_windows.bat first."
}

$outZip = Join-Path $PSScriptRoot "$releaseName.zip"
if (Test-Path -LiteralPath $outZip) { Remove-Item -LiteralPath $outZip -Force }

Compress-Archive -LiteralPath $folder -DestinationPath $outZip -Force
$sha = Get-FileHash -Algorithm SHA256 -LiteralPath $outZip
$line = "$($sha.Hash)  $(Split-Path -Leaf $outZip)"
Set-Content -LiteralPath (Join-Path $PSScriptRoot "SHA256SUMS.txt") -Value $line -Encoding UTF8

Write-Host "DONE"
Write-Host $outZip
Write-Host $line
