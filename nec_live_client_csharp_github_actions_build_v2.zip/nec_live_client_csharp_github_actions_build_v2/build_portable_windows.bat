@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo NEC Live Client C# WinForms Portable Build
echo ============================================================

where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET SDK is not installed or not in PATH.
  echo Install .NET 8 SDK on the operator PC only.
  echo https://dotnet.microsoft.com/download
  pause
  exit /b 1
)

if exist publish rmdir /s /q publish

dotnet publish ".\NEC_Live_Client\NEC_Live_Client.csproj" -c Release -r win-x64 --self-contained true ^
  /p:PublishSingleFile=false ^
  /p:PublishReadyToRun=false ^
  /p:PublishTrimmed=false ^
  /p:PublishDir="..\publish\NEC_Live_Client\"

if errorlevel 1 (
  echo dotnet publish failed.
  pause
  exit /b 1
)

mkdir "publish\NEC_Live_Client\config" 2>nul
copy /Y "NEC_Live_Client\config\client_local.sample.json" "publish\NEC_Live_Client\config\client_local.json" >nul
copy /Y "README_�����о��ּ���.txt" "publish\NEC_Live_Client\README_�����о��ּ���.txt" >nul

echo.
echo DONE.
echo Portable folder:
echo %CD%\publish\NEC_Live_Client
echo.
echo Now run make_release_zip_windows.ps1 or zip the folder manually.
pause
