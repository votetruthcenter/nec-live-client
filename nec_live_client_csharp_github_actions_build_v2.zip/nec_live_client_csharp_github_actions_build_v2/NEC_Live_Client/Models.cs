using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace NEC_Live_Client;

public sealed class ClientLocal
{
    [JsonPropertyName("client_id")]
    public string ClientId { get; set; } = "client_001";

    [JsonPropertyName("operator_alias")]
    public string OperatorAlias { get; set; } = "";

    [JsonPropertyName("config_url")]
    public string ConfigUrl { get; set; } = "";

    [JsonPropertyName("control_url")]
    public string ControlUrl { get; set; } = "";

    [JsonPropertyName("message_url")]
    public string MessageUrl { get; set; } = "";

    [JsonPropertyName("heartbeat_url")]
    public string HeartbeatUrl { get; set; } = "";

    [JsonPropertyName("upload_url")]
    public string UploadUrl { get; set; } = "";

    [JsonPropertyName("upload_token")]
    public string UploadToken { get; set; } = "";

    [JsonPropertyName("out_root")]
    public string OutRoot { get; set; } = "%LOCALAPPDATA%\\NEC_LIVE_CLIENT_DATA";

    [JsonPropertyName("config_poll_sec")]
    public int ConfigPollSec { get; set; } = 30;

    [JsonPropertyName("heartbeat_sec")]
    public int HeartbeatSec { get; set; } = 30;

    [JsonPropertyName("upload_interval_sec")]
    public int UploadIntervalSec { get; set; } = 60;

    [JsonPropertyName("timeout_sec")]
    public int TimeoutSec { get; set; } = 15;

    [JsonPropertyName("user_agent")]
    public string UserAgent { get; set; } = "Mozilla/5.0 NEC-Live-Client-CSharp/2026";
}

public sealed class RemoteConfig
{
    [JsonPropertyName("version")]
    public string Version { get; set; } = "-";

    [JsonPropertyName("schema_version")]
    public int SchemaVersion { get; set; } = 1;

    [JsonPropertyName("mode")]
    public string Mode { get; set; } = "TEST";

    [JsonPropertyName("targets")]
    public List<TargetItem> Targets { get; set; } = new();

    [JsonPropertyName("intervals")]
    public Dictionary<string, IntervalSpec> Intervals { get; set; } = new();
}

public sealed class IntervalSpec
{
    [JsonPropertyName("base_sec")]
    public int BaseSec { get; set; } = 30;

    [JsonPropertyName("min_sec")]
    public int MinSec { get; set; } = 20;

    [JsonPropertyName("max_sec")]
    public int MaxSec { get; set; } = 40;
}

public sealed class TargetItem
{
    [JsonPropertyName("target_id")]
    public string TargetId { get; set; } = "target";

    [JsonPropertyName("menu")]
    public string Menu { get; set; } = "count_status";

    [JsonPropertyName("method")]
    public string Method { get; set; } = "GET";

    [JsonPropertyName("url")]
    public string Url { get; set; } = "https://example.com/";

    [JsonPropertyName("description")]
    public string Description { get; set; } = "";

    [JsonPropertyName("post_body")]
    public Dictionary<string, string> PostBody { get; set; } = new();
}

public sealed class ControlConfig
{
    [JsonPropertyName("version")]
    public string Version { get; set; } = "-";

    [JsonPropertyName("mode")]
    public string Mode { get; set; } = "LIVE";

    [JsonPropertyName("pause_all")]
    public bool PauseAll { get; set; } = false;

    [JsonPropertyName("global_interval_multiplier")]
    public double GlobalIntervalMultiplier { get; set; } = 1.0;

    [JsonPropertyName("upload_interval_sec")]
    public int UploadIntervalSec { get; set; } = 60;

    [JsonPropertyName("upload_max_files_per_batch")]
    public int UploadMaxFilesPerBatch { get; set; } = 20;

    [JsonPropertyName("disable_upload_html")]
    public bool DisableUploadHtml { get; set; } = false;

    [JsonPropertyName("message")]
    public string Message { get; set; } = "";
}

public sealed class OperatorMessage
{
    [JsonPropertyName("version")]
    public string Version { get; set; } = "-";

    [JsonPropertyName("enabled")]
    public bool Enabled { get; set; } = true;

    [JsonPropertyName("level")]
    public string Level { get; set; } = "info";

    [JsonPropertyName("title")]
    public string Title { get; set; } = "운영자 메시지";

    [JsonPropertyName("message")]
    public string Message { get; set; } = "";

    [JsonPropertyName("show_popup")]
    public bool ShowPopup { get; set; } = false;

    [JsonPropertyName("require_ack")]
    public bool RequireAck { get; set; } = false;

    [JsonPropertyName("created_at")]
    public string CreatedAt { get; set; } = "";
}
