using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NEC_Live_Client;

public sealed class MainForm : Form
{
    private const string AppVersion = "v2026.06.03-csharp-sample1";

    private readonly Font _fontBase = new("Malgun Gothic", 12F, FontStyle.Regular);
    private readonly Font _fontTitle = new("Malgun Gothic", 22F, FontStyle.Bold);
    private readonly Font _fontSection = new("Malgun Gothic", 14F, FontStyle.Bold);
    private readonly Font _fontButton = new("Malgun Gothic", 13.5F, FontStyle.Bold);
    private readonly Font _fontStatus = new("Malgun Gothic", 13F, FontStyle.Regular);
    private readonly Font _fontMono = new("Consolas", 10.5F, FontStyle.Regular);

    private readonly JsonSerializerOptions _jsonOpt = new()
    {
        PropertyNameCaseInsensitive = true,
        WriteIndented = true
    };

    private ClientLocal _local = new();
    private RemoteConfig _config = new();
    private ControlConfig _control = new();
    private OperatorMessage _message = new();

    private readonly HttpClient _http = new();
    private readonly ConcurrentQueue<string> _logQueue = new();
    private readonly Random _rng = new();

    private CancellationTokenSource? _cts;
    private bool _running = false;
    private int _okCount = 0;
    private int _failCount = 0;
    private string _lastFetch = "-";
    private string _lastHeartbeat = "-";
    private string _lastUpload = "-";
    private string _lastError = "-";
    private readonly Dictionary<string, DateTime> _nextDue = new();
    private readonly Dictionary<string, string> _lastHash = new();

    private readonly string _appDir;
    private string _outRoot = "";
    private string _rawDir = "";
    private string _metaDir = "";
    private string _logsDir = "";
    private string _queueDir = "";

    // UI
    private Label _statusLabel = null!;
    private Label _serverLabel = null!;
    private Label _clientIdLabel = null!;
    private Label _configLabel = null!;
    private Label _controlLabel = null!;
    private Label _targetCountLabel = null!;
    private Label _lastFetchLabel = null!;
    private Label _lastHeartbeatLabel = null!;
    private Label _lastUploadLabel = null!;
    private Label _queueCountLabel = null!;
    private Label _okFailLabel = null!;
    private Label _messageTitleLabel = null!;
    private Label _messageBodyLabel = null!;
    private Label _errorLabel = null!;
    private RichTextBox _logBox = null!;
    private Button _startButton = null!;
    private Button _stopButton = null!;

    public MainForm()
    {
        _appDir = AppContext.BaseDirectory;
        Text = "NEC Live Client";
        Width = 1180;
        Height = 780;
        MinimumSize = new Size(1040, 700);
        StartPosition = FormStartPosition.CenterScreen;
        Font = _fontBase;
        BackColor = Color.FromArgb(245, 247, 250);

        LoadLocalConfig();
        SetupHttpClient();
        BuildUi();
        ApplyInitialStatus();

        var timer = new System.Windows.Forms.Timer { Interval = 300 };
        timer.Tick += (_, _) => DrainLogs();
        timer.Start();
    }

    private static string NowKst() => DateTimeOffset.UtcNow.ToOffset(TimeSpan.FromHours(9)).ToString("yyyy-MM-dd HH:mm:ss");

    private void LoadLocalConfig()
    {
        var configDir = Path.Combine(_appDir, "config");
        Directory.CreateDirectory(configDir);
        var path = Path.Combine(configDir, "client_local.json");

        if (!File.Exists(path))
        {
            var sample = JsonSerializer.Serialize(new ClientLocal(), _jsonOpt);
            File.WriteAllText(path, sample, Encoding.UTF8);
        }

        var json = File.ReadAllText(path, Encoding.UTF8);
        _local = JsonSerializer.Deserialize<ClientLocal>(json, _jsonOpt) ?? new ClientLocal();

        _outRoot = ExpandPath(_local.OutRoot);
        _rawDir = Path.Combine(_outRoot, "raw_html");
        _metaDir = Path.Combine(_outRoot, "meta");
        _logsDir = Path.Combine(_outRoot, "logs");
        _queueDir = Path.Combine(_outRoot, "upload_queue");
        Directory.CreateDirectory(_rawDir);
        Directory.CreateDirectory(_metaDir);
        Directory.CreateDirectory(_logsDir);
        Directory.CreateDirectory(_queueDir);
    }

    private void SetupHttpClient()
    {
        _http.Timeout = TimeSpan.FromSeconds(Math.Max(5, _local.TimeoutSec));
        _http.DefaultRequestHeaders.UserAgent.ParseAdd(_local.UserAgent);
        _http.DefaultRequestHeaders.CacheControl = new System.Net.Http.Headers.CacheControlHeaderValue { NoCache = true };
    }

    private static string ExpandPath(string path)
    {
        var expanded = Environment.ExpandEnvironmentVariables(path);
        return Path.GetFullPath(expanded);
    }

    private void BuildUi()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(18),
            ColumnCount = 1,
            RowCount = 6,
            BackColor = BackColor
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 62));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 86));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 175));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 125));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        Controls.Add(root);

        var header = new Panel { Dock = DockStyle.Fill, BackColor = BackColor };
        var title = new Label
        {
            Text = "NEC Live Client",
            Font = _fontTitle,
            AutoSize = true,
            Location = new Point(0, 8)
        };
        var version = new Label
        {
            Text = AppVersion,
            Font = new Font("Malgun Gothic", 10.5F),
            ForeColor = Color.DimGray,
            AutoSize = true,
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
            Location = new Point(900, 22)
        };
        header.Controls.Add(title);
        header.Controls.Add(version);
        root.Controls.Add(header, 0, 0);

        var buttonPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            BackColor = BackColor,
            Padding = new Padding(0, 8, 0, 8)
        };
        _startButton = BigButton("수집 시작", Color.FromArgb(20, 120, 80), Color.White);
        _stopButton = BigButton("수집 중지", Color.FromArgb(175, 55, 55), Color.White);
        var logsButton = BigButton("로그 폴더", Color.FromArgb(55, 90, 145), Color.White);
        var dataButton = BigButton("데이터 폴더", Color.FromArgb(55, 90, 145), Color.White);

        _startButton.Click += async (_, _) => await StartCollectionAsync();
        _stopButton.Click += (_, _) => StopCollectionWithConfirm();
        logsButton.Click += (_, _) => OpenFolder(_logsDir);
        dataButton.Click += (_, _) => OpenFolder(_outRoot);

        buttonPanel.Controls.AddRange(new Control[] { _startButton, _stopButton, logsButton, dataButton });
        root.Controls.Add(buttonPanel, 0, 1);

        var statusBox = GroupBox("현재 상태");
        var statusGrid = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 4,
            RowCount = 5,
            Padding = new Padding(12)
        };
        for (var i = 0; i < 4; i++) statusGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        for (var i = 0; i < 5; i++) statusGrid.RowStyles.Add(new RowStyle(SizeType.Percent, 20));
        statusBox.Controls.Add(statusGrid);

        _statusLabel = AddStatus(statusGrid, 0, 0, "상태");
        _serverLabel = AddStatus(statusGrid, 1, 0, "서버");
        _clientIdLabel = AddStatus(statusGrid, 2, 0, "Client ID");
        _targetCountLabel = AddStatus(statusGrid, 3, 0, "담당 타깃");
        _configLabel = AddStatus(statusGrid, 0, 1, "Config");
        _controlLabel = AddStatus(statusGrid, 1, 1, "Control");
        _lastFetchLabel = AddStatus(statusGrid, 2, 1, "마지막 수집");
        _lastHeartbeatLabel = AddStatus(statusGrid, 3, 1, "Heartbeat");
        _lastUploadLabel = AddStatus(statusGrid, 0, 2, "업로드");
        _queueCountLabel = AddStatus(statusGrid, 1, 2, "업로드 대기");
        _okFailLabel = AddStatus(statusGrid, 2, 2, "성공/실패");
        root.Controls.Add(statusBox, 0, 2);

        var messageBox = GroupBox("운영자 메시지");
        var msgPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(14), BackColor = Color.FromArgb(255, 252, 232) };
        _messageTitleLabel = new Label
        {
            Text = "아직 메시지가 없습니다.",
            Font = new Font("Malgun Gothic", 14.5F, FontStyle.Bold),
            ForeColor = Color.FromArgb(80, 60, 0),
            Dock = DockStyle.Top,
            Height = 34
        };
        _messageBodyLabel = new Label
        {
            Text = "프로그램을 실행한 뒤 서버 연결 상태를 확인하세요.",
            Font = new Font("Malgun Gothic", 13F),
            ForeColor = Color.FromArgb(60, 60, 60),
            Dock = DockStyle.Fill
        };
        msgPanel.Controls.Add(_messageBodyLabel);
        msgPanel.Controls.Add(_messageTitleLabel);
        messageBox.Controls.Add(msgPanel);
        root.Controls.Add(messageBox, 0, 3);

        var errorBox = GroupBox("마지막 오류");
        _errorLabel = new Label
        {
            Text = "-",
            Dock = DockStyle.Fill,
            Padding = new Padding(12),
            Font = new Font("Malgun Gothic", 12.5F),
            ForeColor = Color.FromArgb(160, 20, 20)
        };
        errorBox.Controls.Add(_errorLabel);
        root.Controls.Add(errorBox, 0, 4);

        var logBoxGroup = GroupBox("실시간 로그");
        _logBox = new RichTextBox
        {
            Dock = DockStyle.Fill,
            Font = _fontMono,
            ReadOnly = true,
            BackColor = Color.FromArgb(25, 28, 34),
            ForeColor = Color.FromArgb(235, 235, 235),
            BorderStyle = BorderStyle.None
        };
        logBoxGroup.Controls.Add(_logBox);
        root.Controls.Add(logBoxGroup, 0, 5);
    }

    private Button BigButton(string text, Color back, Color fore)
    {
        return new Button
        {
            Text = text,
            Font = _fontButton,
            Width = 165,
            Height = 58,
            Margin = new Padding(0, 0, 14, 0),
            BackColor = back,
            ForeColor = fore,
            FlatStyle = FlatStyle.Flat,
            Cursor = Cursors.Hand
        };
    }

    private GroupBox GroupBox(string text)
    {
        return new GroupBox
        {
            Text = text,
            Dock = DockStyle.Fill,
            Font = _fontSection,
            Padding = new Padding(10),
            BackColor = Color.White
        };
    }

    private Label AddStatus(TableLayoutPanel grid, int col, int row, string name)
    {
        var panel = new Panel
        {
            Dock = DockStyle.Fill,
            Margin = new Padding(4),
            BackColor = Color.FromArgb(248, 249, 252),
            Padding = new Padding(10)
        };

        var nameLabel = new Label
        {
            Text = name,
            Font = new Font("Malgun Gothic", 10F, FontStyle.Bold),
            ForeColor = Color.DimGray,
            Dock = DockStyle.Top,
            Height = 24
        };

        var valueLabel = new Label
        {
            Text = "-",
            Font = _fontStatus,
            ForeColor = Color.FromArgb(30, 30, 30),
            Dock = DockStyle.Fill
        };

        panel.Controls.Add(valueLabel);
        panel.Controls.Add(nameLabel);
        grid.Controls.Add(panel, col, row);
        return valueLabel;
    }

    private void ApplyInitialStatus()
    {
        _clientIdLabel.Text = _local.ClientId;
        _statusLabel.Text = "정지";
        _serverLabel.Text = "대기";
        _configLabel.Text = "-";
        _controlLabel.Text = "-";
        _targetCountLabel.Text = "0";
        _lastFetchLabel.Text = "-";
        _lastHeartbeatLabel.Text = "-";
        _lastUploadLabel.Text = "-";
        _queueCountLabel.Text = "0";
        _okFailLabel.Text = "0 / 0";
        _errorLabel.Text = "-";
    }

    private async Task StartCollectionAsync()
    {
        if (_running)
        {
            Log("이미 수집 중입니다.");
            return;
        }

        if (string.IsNullOrWhiteSpace(_local.ConfigUrl))
        {
            MessageBox.Show("config\\client_local.json의 config_url을 먼저 설정해야 합니다.", "설정 필요",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        _cts = new CancellationTokenSource();
        _running = true;
        _statusLabel.Text = "수집 중";
        _serverLabel.Text = "연결 시도";
        Log("수집 시작");

        await Task.Run(() => WorkerLoopAsync(_cts.Token));
    }

    private void StopCollectionWithConfirm()
    {
        if (!_running)
        {
            Log("현재 수집 중이 아닙니다.");
            return;
        }

        var result = MessageBox.Show(
            "수집을 중지하시겠습니까?\n\n중지하면 운영자가 중앙 상태판에서 이 PC를 오프라인 또는 정지 상태로 볼 수 있습니다.",
            "수집 중지 확인",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question,
            MessageBoxDefaultButton.Button2
        );

        if (result != DialogResult.Yes)
        {
            Log("수집 중지 취소");
            return;
        }

        _cts?.Cancel();
        _running = false;
        _statusLabel.Text = "정지";
        Log("수집 중지 요청");
    }

    private async Task WorkerLoopAsync(CancellationToken token)
    {
        DateTime nextConfig = DateTime.MinValue;
        DateTime nextHeartbeat = DateTime.MinValue;
        DateTime nextUpload = DateTime.MinValue;

        while (!token.IsCancellationRequested)
        {
            try
            {
                var now = DateTime.UtcNow;

                if (now >= nextConfig)
                {
                    await RefreshJsonSettingsAsync(token);
                    nextConfig = now.AddSeconds(Math.Max(10, _local.ConfigPollSec));
                }

                if (now >= nextHeartbeat)
                {
                    await SendHeartbeatAsync(token);
                    nextHeartbeat = now.AddSeconds(Math.Max(10, _local.HeartbeatSec));
                }

                if (now >= nextUpload)
                {
                    await UploadManifestBatchAsync(token);
                    var interval = _control.UploadIntervalSec > 0 ? _control.UploadIntervalSec : _local.UploadIntervalSec;
                    nextUpload = now.AddSeconds(Math.Max(30, interval));
                }

                await RunDueTargetsAsync(token);
                UpdateStatusUi();

                await Task.Delay(500, token);
            }
            catch (TaskCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _failCount++;
                _lastError = ex.Message;
                Log("Worker error: " + ex.Message);
                UpdateStatusUi();
                await Task.Delay(3000, token);
            }
        }

        BeginInvoke(() =>
        {
            _running = false;
            _statusLabel.Text = "정지";
            Log("Worker stopped");
        });
    }

    private async Task RefreshJsonSettingsAsync(CancellationToken token)
    {
        var cfg = await GetJsonAsync<RemoteConfig>(_local.ConfigUrl, token);
        if (cfg != null)
        {
            var old = _config.Version;
            _config = cfg;
            if (old != cfg.Version)
            {
                Log("config applied: " + cfg.Version);
                ResetSchedule();
            }
        }

        var ctl = await GetJsonAsync<ControlConfig>(_local.ControlUrl, token);
        if (ctl != null) _control = ctl;

        var msg = await GetJsonAsync<OperatorMessage>(_local.MessageUrl, token);
        if (msg != null)
        {
            var oldMsg = _message.Version;
            _message = msg;
            if (oldMsg != msg.Version) Log($"operator message: [{msg.Level}] {msg.Title}");
        }

        BeginInvoke(UpdateStatusUi);
    }

    private async Task<T?> GetJsonAsync<T>(string url, CancellationToken token) where T : class
    {
        if (string.IsNullOrWhiteSpace(url)) return null;
        try
        {
            var text = await _http.GetStringAsync(url, token);
            return JsonSerializer.Deserialize<T>(text, _jsonOpt);
        }
        catch (Exception ex)
        {
            _lastError = $"JSON load failed: {ex.Message}";
            Log(_lastError);
            return null;
        }
    }

    private void ResetSchedule()
    {
        _nextDue.Clear();
        var now = DateTime.UtcNow;
        foreach (var t in _config.Targets)
        {
            _nextDue[t.TargetId] = now.AddSeconds(_rng.Next(0, 120)); // initial phase offset
        }
    }

    private async Task RunDueTargetsAsync(CancellationToken token)
    {
        if (!_running) return;
        if (_control.PauseAll || _control.Mode.Equals("PAUSE", StringComparison.OrdinalIgnoreCase))
        {
            BeginInvoke(() => _statusLabel.Text = "중앙 일시정지");
            return;
        }

        var now = DateTime.UtcNow;
        foreach (var target in _config.Targets)
        {
            token.ThrowIfCancellationRequested();

            if (!_nextDue.TryGetValue(target.TargetId, out var due))
            {
                _nextDue[target.TargetId] = now.AddSeconds(_rng.Next(0, 120));
                continue;
            }

            if (now < due) continue;

            try
            {
                var result = await FetchTargetAsync(target, token);
                await SaveFetchResultAsync(target, result.Status, result.Body, result.Headers, result.FinalUrl, token);
                _okCount++;
                _lastFetch = NowKst();
                Log($"OK {target.TargetId} status={result.Status} bytes={result.Body.Length}");
                _nextDue[target.TargetId] = DateTime.UtcNow.AddSeconds(GetRandomInterval(target));
            }
            catch (Exception ex)
            {
                _failCount++;
                _lastError = $"{target.TargetId}: {ex.Message}";
                Log("FAIL " + _lastError);
                _nextDue[target.TargetId] = DateTime.UtcNow.AddSeconds(Math.Min(GetRandomInterval(target) * 2, 300));
            }
        }
    }

    private async Task<(int Status, byte[] Body, Dictionary<string, string> Headers, string FinalUrl)> FetchTargetAsync(TargetItem target, CancellationToken token)
    {
        using var req = new HttpRequestMessage(
            target.Method.Equals("POST", StringComparison.OrdinalIgnoreCase) ? HttpMethod.Post : HttpMethod.Get,
            target.Url
        );

        if (req.Method == HttpMethod.Post)
        {
            req.Content = new FormUrlEncodedContent(target.PostBody);
        }

        using var resp = await _http.SendAsync(req, token);
        var body = await resp.Content.ReadAsByteArrayAsync(token);
        var headers = resp.Headers.ToDictionary(k => k.Key, v => string.Join("; ", v.Value));
        foreach (var h in resp.Content.Headers)
            headers[h.Key] = string.Join("; ", h.Value);

        return ((int)resp.StatusCode, body, headers, resp.RequestMessage?.RequestUri?.ToString() ?? target.Url);
    }

    private async Task SaveFetchResultAsync(TargetItem target, int status, byte[] body, Dictionary<string, string> headers, string finalUrl, CancellationToken token)
    {
        var hash = Sha256(body);
        var changed = !_lastHash.TryGetValue(target.TargetId, out var oldHash) || oldHash != hash;
        _lastHash[target.TargetId] = hash;

        var date = DateTimeOffset.UtcNow.ToOffset(TimeSpan.FromHours(9)).ToString("yyyyMMdd");
        var ts = DateTimeOffset.UtcNow.ToOffset(TimeSpan.FromHours(9)).ToString("yyyyMMdd_HHmmss");
        var menu = SafeName(target.Menu);
        var tid = SafeName(target.TargetId);

        var rawPath = Path.Combine(_rawDir, date, _local.ClientId, menu, $"{ts}_{tid}_{hash[..12]}.html.gz");
        var metaPath = Path.Combine(_metaDir, date, _local.ClientId, menu, $"{ts}_{tid}_{hash[..12]}.json");
        Directory.CreateDirectory(Path.GetDirectoryName(rawPath)!);
        Directory.CreateDirectory(Path.GetDirectoryName(metaPath)!);

        await using (var fs = File.Create(rawPath))
        await using (var gz = new GZipStream(fs, CompressionLevel.Optimal))
        {
            await gz.WriteAsync(body, token);
        }

        var meta = new
        {
            app_version = AppVersion,
            client_id = _local.ClientId,
            operator_alias = _local.OperatorAlias,
            fetched_at_kst = NowKst(),
            target,
            http_status = status,
            final_url = finalUrl,
            response_headers = headers,
            html_sha256 = hash,
            raw_html_gz = rawPath,
            changed_from_previous = changed,
            content_bytes = body.Length
        };

        await File.WriteAllTextAsync(metaPath, JsonSerializer.Serialize(meta, _jsonOpt), Encoding.UTF8, token);

        var queueItem = new
        {
            meta_path = metaPath,
            raw_path = changed ? rawPath : "",
            queued_at_kst = NowKst(),
            target_id = target.TargetId,
            html_sha256 = hash,
            changed
        };

        var qpath = Path.Combine(_queueDir, $"{ts}_{tid}_{hash[..12]}.json");
        await File.WriteAllTextAsync(qpath, JsonSerializer.Serialize(queueItem, _jsonOpt), Encoding.UTF8, token);
    }

    private double GetRandomInterval(TargetItem target)
    {
        IntervalSpec? spec = null;
        if (_config.Intervals.TryGetValue(target.Menu, out var menuSpec)) spec = menuSpec;
        else if (_config.Intervals.TryGetValue("default", out var defaultSpec)) spec = defaultSpec;
        spec ??= new IntervalSpec();

        var min = Math.Max(1, spec.MinSec);
        var max = Math.Max(min, spec.MaxSec);
        var mult = _control.GlobalIntervalMultiplier <= 0 ? 1.0 : _control.GlobalIntervalMultiplier;
        return (_rng.NextDouble() * (max - min) + min) * mult;
    }

    private async Task SendHeartbeatAsync(CancellationToken token)
    {
        if (string.IsNullOrWhiteSpace(_local.HeartbeatUrl)) return;

        var payload = new
        {
            type = "heartbeat",
            app_version = AppVersion,
            client_id = _local.ClientId,
            operator_alias = _local.OperatorAlias,
            status = _control.PauseAll ? "PAUSED" : (_running ? "RUNNING" : "STOPPED"),
            config_version = _config.Version,
            control_version = _control.Version,
            message_version = _message.Version,
            assigned_targets = _config.Targets.Count,
            last_fetch_at = _lastFetch,
            last_upload_at = _lastUpload,
            ok_count = _okCount,
            fail_count = _failCount,
            upload_queue_count = Directory.GetFiles(_queueDir, "*.json").Length,
            last_error = _lastError == "-" ? "" : _lastError,
            sent_at_kst = NowKst()
        };

        try
        {
            var json = JsonSerializer.Serialize(payload, _jsonOpt);
            using var req = new HttpRequestMessage(HttpMethod.Post, _local.HeartbeatUrl)
            {
                Content = new StringContent(json, Encoding.UTF8, "application/json")
            };
            req.Headers.TryAddWithoutValidation("X-NEC-Client-ID", _local.ClientId);
            req.Headers.TryAddWithoutValidation("X-NEC-Upload-Token", _local.UploadToken);

            using var resp = await _http.SendAsync(req, token);
            _lastHeartbeat = NowKst();
            if (!resp.IsSuccessStatusCode) Log("heartbeat HTTP " + (int)resp.StatusCode);
        }
        catch (Exception ex)
        {
            _lastError = "heartbeat failed: " + ex.Message;
            Log(_lastError);
        }
    }

    private async Task UploadManifestBatchAsync(CancellationToken token)
    {
        if (string.IsNullOrWhiteSpace(_local.UploadUrl)) return;

        var files = Directory.GetFiles(_queueDir, "*.json")
            .OrderBy(x => x)
            .Take(Math.Max(1, _control.UploadMaxFilesPerBatch))
            .ToList();

        if (files.Count == 0) return;

        var items = new List<JsonElement>();
        foreach (var f in files)
        {
            try
            {
                var text = await File.ReadAllTextAsync(f, Encoding.UTF8, token);
                items.Add(JsonDocument.Parse(text).RootElement.Clone());
            }
            catch { }
        }

        var payload = new
        {
            type = "upload_manifest_batch",
            app_version = AppVersion,
            client_id = _local.ClientId,
            items,
            sent_at_kst = NowKst()
        };

        try
        {
            var json = JsonSerializer.Serialize(payload, _jsonOpt);
            using var req = new HttpRequestMessage(HttpMethod.Post, _local.UploadUrl)
            {
                Content = new StringContent(json, Encoding.UTF8, "application/json")
            };
            req.Headers.TryAddWithoutValidation("X-NEC-Client-ID", _local.ClientId);
            req.Headers.TryAddWithoutValidation("X-NEC-Upload-Token", _local.UploadToken);

            using var resp = await _http.SendAsync(req, token);
            if (resp.IsSuccessStatusCode)
            {
                foreach (var f in files)
                {
                    try { File.Delete(f); } catch { }
                }
                _lastUpload = NowKst();
                Log("upload manifest OK count=" + files.Count);
            }
            else
            {
                Log("upload manifest HTTP " + (int)resp.StatusCode);
            }
        }
        catch (Exception ex)
        {
            _lastError = "upload failed: " + ex.Message;
            Log(_lastError);
        }
    }

    private void UpdateStatusUi()
    {
        if (InvokeRequired)
        {
            BeginInvoke(UpdateStatusUi);
            return;
        }

        _statusLabel.Text = _control.PauseAll ? "중앙 일시정지" : (_running ? "수집 중" : "정지");
        _serverLabel.Text = string.IsNullOrWhiteSpace(_lastError) || _lastError == "-" ? "정상" : "확인 필요";
        _clientIdLabel.Text = _local.ClientId;
        _configLabel.Text = _config.Version;
        _controlLabel.Text = _control.Version;
        _targetCountLabel.Text = _config.Targets.Count.ToString();
        _lastFetchLabel.Text = _lastFetch;
        _lastHeartbeatLabel.Text = _lastHeartbeat;
        _lastUploadLabel.Text = _lastUpload;
        _queueCountLabel.Text = Directory.Exists(_queueDir) ? Directory.GetFiles(_queueDir, "*.json").Length.ToString() : "0";
        _okFailLabel.Text = $"{_okCount} / {_failCount}";
        _errorLabel.Text = _lastError;

        if (_message.Enabled)
        {
            _messageTitleLabel.Text = $"[{_message.Level.ToUpperInvariant()}] {_message.Title}";
            _messageBodyLabel.Text = $"{_message.Message}\n{_message.CreatedAt}";
        }
    }

    private void Log(string message)
    {
        var line = $"[{NowKst()}] {message}";
        _logQueue.Enqueue(line);
        try
        {
            Directory.CreateDirectory(_logsDir);
            var path = Path.Combine(_logsDir, $"client_{DateTime.Now:yyyyMMdd}.log");
            File.AppendAllText(path, line + Environment.NewLine, Encoding.UTF8);
        }
        catch { }
    }

    private void DrainLogs()
    {
        while (_logQueue.TryDequeue(out var line))
        {
            _logBox.AppendText(line + Environment.NewLine);
            _logBox.ScrollToCaret();
        }
    }

    private static string Sha256(byte[] data)
    {
        var hash = SHA256.HashData(data);
        return Convert.ToHexString(hash).ToLowerInvariant();
    }

    private static string SafeName(string value)
    {
        var bad = Path.GetInvalidFileNameChars().Concat(new[] { ' ', '\t', '\r', '\n' }).ToHashSet();
        var sb = new StringBuilder();
        foreach (var ch in value)
            sb.Append(bad.Contains(ch) ? '_' : ch);
        var result = sb.ToString().Trim('_');
        return string.IsNullOrWhiteSpace(result) ? "item" : result;
    }

    private static void OpenFolder(string path)
    {
        Directory.CreateDirectory(path);
        Process.Start(new ProcessStartInfo
        {
            FileName = path,
            UseShellExecute = true
        });
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if (_running)
        {
            var result = MessageBox.Show(
                "수집이 실행 중입니다. 정말 프로그램을 종료할까요?",
                "종료 확인",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2
            );

            if (result != DialogResult.Yes)
            {
                e.Cancel = true;
                return;
            }
        }

        _cts?.Cancel();
        base.OnFormClosing(e);
    }
}
